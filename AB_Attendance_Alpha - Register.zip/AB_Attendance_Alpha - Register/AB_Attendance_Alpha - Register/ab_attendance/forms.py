from enum import unique
from flask_wtf import FlaskForm
from wtforms import StringField,PasswordField, SubmitField, BooleanField, DateTimeField
from wtforms.validators import DataRequired, Length, ValidationError



class RegistrationForm(FlaskForm):
    employee_id = StringField('Employee ID',
                           validators=[DataRequired()])
    submit = SubmitField('Submit')

class LoginForm(FlaskForm):
    username = StringField('Username',
                           validators=[DataRequired(), Length(min=2, max=20)])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')


class AttendanceForm(FlaskForm):
    employee_id = StringField('Employee ID',
                           validators=[DataRequired(), Length(min=1, max=5)])
    date_time = DateTimeField('Date Time', validators=[DataRequired()])
    submit = SubmitField('Confirm')