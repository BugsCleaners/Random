from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager 
from flask_bcrypt import Bcrypt


app=Flask(__name__)
app.config['SECRET_KEY'] = '5791628bb0b13ce0c676dfde280ba245'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@localhost:3307/attendance_db'
bcrypt = Bcrypt(app)

app.config['success'] = 0
app.config['name'] = ''
app.config['shot'] = 0
app.config['capture'] = 0
app.config['unknown'] = 0



db = SQLAlchemy(app)
login_manager = LoginManager(app)


from ab_attendance import routes