from flask import render_template, Response, url_for, flash, redirect, request, abort
from ab_attendance import app, db, login_manager, bcrypt
from ab_attendance.forms import RegistrationForm, LoginForm
from ab_attendance.models import Developer, RegisteredUsers, logs__history
from flask_login import login_user, current_user, logout_user, login_required
import datetime, time
from datetime import datetime
import cv2
from datetime import date
from sqlalchemy.exc import IntegrityError
import os
from http import HTTPStatus


#Face Detection
#make shots directory to save pics
try:
    os.mkdir('./shots')
except OSError as error:
    pass


def gen_frames_():  # generate frame by frame from camera
    while True:
        success, frame = camera.read()
        if success:
            if app.config['capture'] == 1:
                frame_ = cv2.flip(frame, 1)
                app.config['capture'] = 0
                try:
                    os.remove(r"C:\Users\Eagle\Desktop\AB\Face_Detection\AB_Attendance_Alpha\ab_attendance\static\test_shot_"+str(app.config['shot'])+".png")
                except:
                    print('no file found')         
                p="ab_attendance/static/test_shot_"+str(app.config['shot'])+".png"                
                cv2.imwrite(p, frame_)
                os.listdir("C:/Users/Eagle/Desktop/AB/Face_Detection/AB_Attendance_Alpha/ab_attendance/static")
            try:
                ret, buffer = cv2.imencode('.jpg', cv2.flip(frame,1))
                frame = buffer.tobytes()
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
            except Exception as e:
                pass
        else:
            pass

                                                      
#Face Recognition
camera = cv2.VideoCapture(1)
camera.set(cv2.CAP_PROP_FPS, 30.0)
camera.set(cv2.CAP_PROP_FRAME_WIDTH, 2560)
camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 1440)    

#Application Structure
@app.route('/')
@app.route("/login", methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('register'))
    form = LoginForm()
    if form.validate_on_submit():
        developer = Developer.query.filter_by(username = form.username.data).first()
        if developer and (form.username.data.lower() == "admin" and bcrypt.check_password_hash(developer.password, form.password.data)) or (form.username.data.lower() == "hr" and bcrypt.check_password_hash(developer.password, form.password.data)):
            logged_user = logs__history(username = form.username.data, date_time = datetime.now())
            db.session.add(logged_user)
            db.session.commit()
            login_user(developer, remember=form.remember.data)
            return redirect(url_for('register'))
        else:
            flash(f'Login Unsuccessful. Please check username and password', 'danger')
    flash(f'Login Unsuccessful. Please check username and password', 'danger')
    return render_template('login.html', title='Login', form=form)

@login_manager.unauthorized_handler
def unauthorized():
    if request.blueprint == 'api':
        abort(HTTPStatus.UNAUTHORIZED)
    return redirect(url_for('login'))

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('login'))


@app.route("/register", methods=['GET', 'POST'])
@login_required
def register():
    if current_user.get_id() in ['1','3']:
        form = RegistrationForm()
        if form.validate_on_submit():
            if len(form.employee_id.data)<=5:
                img_path = os.path.sep.join(['shots', "shot_{}_{employee_id}".format(str(date.today()),employee_id = form.employee_id.data)])
                cv2.imwrite(img_path+"_0.png", cv2.imread("ab_attendance/static/test_shot_0.png"))
                cv2.imwrite(img_path+"_1.png", cv2.imread("ab_attendance/static/test_shot_1.png"))
                user = RegisteredUsers(employee_id = form.employee_id.data, image_path = img_path+"_0.png/_1.png", logged_by = current_user.get_id(), date_time = datetime.now())
                db.session.add(user)
                try:
                    db.session.commit()
                    flash(f'ID Registered Successfully!', 'success') 
                except IntegrityError as err:
                    db.session.rollback()
                    if "PRIMARY" in str(err):
                        flash("Error, employee already exists (%s)" % form.employee_id.data, 'danger')
                    elif "FOREIGN KEY constraint failed" in str(err):
                        flash("Employee does not exist", 'danger')
                    else:
                        flash("Unknown error adding employee", 'danger')  
                return redirect(url_for('register'))
            else:
                flash(f'Employee ID must be between 1 and 5 characters', 'danger')
                return redirect(url_for('register'))
        return render_template('register.html', title='Register', form=form)
    else:
        return redirect(url_for('logout'))


@app.route('/video_feed_')
@login_required
def video_feed_():
    if current_user.get_id() in ['1','3']:
        return Response(gen_frames_(), mimetype='multipart/x-mixed-replace; boundary=frame')
    else:
        return redirect(url_for('logout'))


@app.route('/capture')
@login_required
def capture():
    if current_user.get_id() in ['1','3']:    
        time.sleep(0.2)
        app.config['capture'] =1
        time.sleep(0.5)
        app.config['shot'] = 1
        app.config['capture'] = 1
        time.sleep(0.5)
        app.config['shot'] = 0
        return ('', 204)
    else:
        return redirect(url_for('logout'))