from ab_attendance import db, login_manager
from flask_login import UserMixin

@login_manager.user_loader
def load_user(user_id):
    return Developer.query.get(int(user_id))


class Developer(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    password = db.Column(db.String(20), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    def __repr__(self):
        return f"Developer('{self.id}', '{self.username}', '{self.role}')"


class RegisteredUsers(db.Model):
    employee_id = db.Column(db.String(5), primary_key=True) # change later to int
    image_path = db.Column(db.String(500), unique=True, nullable=False) 
    logged_by = db.Column(db.String(5), nullable=False)
    date_time = db.Column(db.DateTime, nullable=False) 

    def __repr__(self):
        return f"User('{self.employee_id}', '{self.image_path}', '{self.logged_by}', '{self.date_time}')"


class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.String(5), nullable=False) # change later to int
    date_time = db.Column(db.DateTime, nullable=False) 
    
    def __repr__(self):
        return f"Attendance('{self.id}', '{self.employee_id}', '{self.date_time}')"

class logs__history(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), nullable=False)
#    role = db.Column(db.String(20), nullable=False)
    date_time = db.Column(db.DateTime, nullable=False) 
    def __repr__(self):
        return f"Developer('{self.id}', '{self.username}', '{self.date_time}')"
