from flask import Flask
from flask_bcrypt import Bcrypt

app= Flask(__name__)
bcrypt = Bcrypt(app)

#hashed_password  = bcrypt.generate_password_hash('password').decode('utf-8')

#print(hashed_password)


#print(bcrypt.check_password_hash('$2b$12$GTA8aWStSIuHOvRUuc2sEOTWikxwzpMAee7ZW7WUDrPBrlMpbUIJm', 'password'))

#hashed_password  = bcrypt.generate_password_hash('Password').decode('utf-8')
#print(hashed_password)

#print(bcrypt.check_password_hash('$2b$12$hIcKyxg3Bp5yjKn38n68Lu3kiaVYstfSZgAPKsswlVR9lkc.dJvEq', 'Password'))