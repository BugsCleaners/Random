from ab_attendance import app

port = 9443


if __name__=='__main__':
    app.run(port = port)

