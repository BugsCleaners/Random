import cv2
import face_recognition
from datetime import date
from datetime import datetime
import shutil
import os
import csv    
import pandas as pd

path = 'shots'
images = []
classNames = []
myList = os.listdir(path)

names_list = pd.read_csv(r'C:\Users\Eagle\Desktop\ihub.csv')

for cl in myList:
    curImg = cv2.imread(f'{path}/{cl}')
    images.append(curImg)
    classNames.append(os.path.splitext(cl)[0])
    os.rename(f'{path}/{cl}', f'{path}/{cl}')


def findEncodings(images):
    encodeList_temp = []
    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)[0]
        encodeList_temp.append(encode)
    return encodeList_temp

temp_face_encodings = findEncodings(images)

df_temp_face_encodings = pd.DataFrame(temp_face_encodings, index = classNames).reset_index()

df_temp_face_encodings.columns = list(range(0,129))

if os.path.exists("sheets/encodings_.csv"):
    df_encodings = pd.read_csv('sheets/encodings.csv', header = None)
    df_encodings = pd.concat([df_encodings, df_temp_face_encodings], axis=0)
    df_encodings.to_csv('sheets/encodings.csv',header=None, index = False)
else:
    df_temp_face_encodings.to_csv('sheets/encodings.csv',header=None, index = False)

source_dir = 'shots'
target_dir = 'ab_attendance/static/ImagesAttendance'

file_names = os.listdir(source_dir)
    
for file_name in file_names:
    shutil.move(os.path.join(source_dir, file_name), target_dir)


# rename images (emp_id + count)