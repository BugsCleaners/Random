import cv2
import face_recognition
import numpy as np
import os
import pandas as pd
import time

program_starts = time.time()

path = 'ab_attendance/static/ImagesAttendance'
images = []
classNames = []
myList = os.listdir(path)


for cl in myList:
    curImg = cv2.imread(f'{path}/{cl}')
    images.append(curImg)
    classNames.append(os.path.splitext(cl)[0])


def findEncodings(images):
    encodeList_temp = []
    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)[0]
        encodeList_temp.append(encode)
    return encodeList_temp


temp_face_encodings = findEncodings(images)

df_temp_face_encodings = pd.DataFrame(temp_face_encodings, index = classNames).reset_index()

df_temp_face_encodings.columns = list(range(0,129))

df_temp_face_encodings.to_csv('sheets/encodings_.csv',header=None, index = False)
now = time.time()
print("It has been {0} seconds since the loop started".format(now - program_starts))